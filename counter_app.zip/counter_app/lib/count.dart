import 'package:flutter/material.dart';

class CountClass extends StatefulWidget {
  const CountClass({super.key});

  @override
  State<CountClass> createState() => _CountClassState();
}

class _CountClassState extends State<CountClass> {
  int count = 0;
  List<int> countHistory = [];

  void _updateCount(int newCount) {
    setState(() {
      count = newCount;
      countHistory.add(newCount);
    });
  }

  void incremet() => _updateCount(count + 1);
  void decrement() => _updateCount(count - 1);
  void reset() => _updateCount(count = 0);
  void addation() => _updateCount(count += 5);
  void clearHistory() {
    setState(() {
      countHistory.clear();
    });
  }

  final ButtonStyle _buttonStyle = ElevatedButton.styleFrom(
    backgroundColor: Colors.blue,
    foregroundColor: Colors.white,
    alignment: Alignment.center,
    elevation: 10,
    shadowColor: Colors.black,

    textStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        centerTitle: true,
        actions: [Icon(Icons.notification_add)],
        leading: DrawerButton(),
        iconTheme: IconThemeData(color: Colors.white, size: 30),
        actionsPadding: EdgeInsets.all(10),
        title: Text(
          " Counter App",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
            color: Colors.white,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 100),
            Text(
              "Count: $count ",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22,
                color:
                    count == 0
                        ? Colors.blue
                        : count > 0
                        ? Colors.black
                        : Colors.red,
              ),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: incremet,
                  style: _buttonStyle,
                  child: Text("Increment"),
                ),
                ElevatedButton(
                  onPressed: decrement,
                  style: _buttonStyle,
                  child: Text("decrement"),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: reset,
                  style: _buttonStyle,
                  child: Text("  Reset All "),
                ),
                ElevatedButton(
                  onPressed: addation,
                  style: _buttonStyle,
                  child: Text("      + 5      "),
                ),
              ],
            ),

            SizedBox(height: 30),
            Text(
              ' 🙋‍♂️ Count History 🔥',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: countHistory.length,
                reverse: true,
                itemBuilder: (context, index) {
                  final historyIndex = countHistory.length - 1 - index;

                  return ListTile(
                    leading: Text(
                      '${historyIndex + 1}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    title: Text(
                      '${countHistory[historyIndex]}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        color:
                            countHistory[historyIndex] == 0
                                ? Colors.blue
                                : countHistory[historyIndex] > 0
                                ? Colors.black
                                : Colors.red,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: clearHistory,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        elevation: 10,
        splashColor: Colors.red,
        tooltip: 'Clear History',
        clipBehavior: Clip.antiAlias,
        child: Icon(Icons.clear, size: 30),
      ),
    );
  }
}
